
describe 'Opcao Check', :selecionaOpcaoCheck do
    it 'CT06 - Seleciona Opção Check' do
        visit 'https://training-wheels-protocol.herokuapp.com/checkboxes'
        check('thor')
        sleep 2
    end

    it 'CT06 - Desmarcando Opção Check' do
        visit 'https://training-wheels-protocol.herokuapp.com/checkboxes'
        find('input[value=guardians]').set(false)
        sleep 2
    end
end