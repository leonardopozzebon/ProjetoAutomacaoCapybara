
describe 'Teclado', :keys do

    before (:each) do
        visit 'https://training-wheels-protocol.herokuapp.com/key_presses'
    end

    it 'CT10 - Simulacao de tecla' do
        find('#campo-id').send_keys :space
        expect(page).to have_content 'You entered: SPACE'
        sleep 2
        find('#campo-id').send_keys :enter
        expect(page).to have_content 'You entered: ENTER'
        sleep 2
    end
end
