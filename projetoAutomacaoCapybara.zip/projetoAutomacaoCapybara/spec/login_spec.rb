#Autor: Leonardo Pozzebon

describe 'Login Formulario', :login  do
    it 'CT02 - Login com sucesso' do
        visit 'https://training-wheels-protocol.herokuapp.com/login'

        #usando o atributo do capybara fill in para preencher o campo
        fill_in 'userId', with: 'stark'
        fill_in 'password', with: 'jarvis!'
        #usando o atributo do capybara click_button para clicar no botão
        click_button 'Login'
        sleep 3
        #usando o atributo do capybara find para validar apos logado se existe mensagem de Boas Vindas
        expect(find('#flash').visible?).to be true
        sleep 3
    end

    it 'CT03 - Usuario não cadastrado' do
        visit 'https://training-wheels-protocol.herokuapp.com/login'

        fill_in 'userId', with: 'Joao'
        
        click_button 'Login'
        sleep 2
        expect(find('#flash')).to have_content 'O usuário informado não está cadastrado!'
        sleep 2
    end

    it 'CT04 - Senha Invalida' do
        visit 'https://training-wheels-protocol.herokuapp.com/login'

        fill_in 'userId', with: 'stark'
        fill_in 'password', with: 'abc123'
        
        click_button 'Login'
        sleep 2
        expect(find('#flash')).to have_content 'Senha é invalida!'
        sleep 2
    end
end
