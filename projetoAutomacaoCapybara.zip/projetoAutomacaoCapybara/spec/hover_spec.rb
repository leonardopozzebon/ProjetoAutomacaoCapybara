describe 'Hover', :hover do
    before(:each) do
        visit 'https://training-wheels-protocol.herokuapp.com/hovers'
    end

    it 'CT08 - Hover Blade' do
        element = find('img[alt=Blade')
        element.hover

        expect(page).to have_content 'Nome: Blade'

    end

    after(:each) do
        sleep 2
    end
end