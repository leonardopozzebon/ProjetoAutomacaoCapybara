
describe 'Mover img', :mover do
    before(:each) do
        visit 'https://training-wheels-protocol.herokuapp.com/drag_and_drop'
    end

    it 'CT09 - Mover img' do
        team = find('.team-stark .column')
        imagem =  find('img[alt$=Aranha]')
        imagem.drag_to team
        sleep 3
    end
end