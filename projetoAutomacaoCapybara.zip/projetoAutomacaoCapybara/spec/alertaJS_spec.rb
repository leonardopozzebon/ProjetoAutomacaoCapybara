
describe 'Alerta do JS', :alerta do
    before (:each) do
        visit 'https://training-wheels-protocol.herokuapp.com/javascript_alerts'
    end

    it 'CT11 - Confirma' do
        click_button 'Confirma'
        msg2 = page.driver.browser.switch_to.alert.text
        expect(msg2).to eql 'E ai confirma?'
        page.driver.browser.switch_to.alert.accept
    end

    it 'CT11 - Nao Confirma' do
        click_button 'Confirma'
        msg2 = page.driver.browser.switch_to.alert.text
        expect(msg2).to eql 'E ai confirma?'
        page.driver.browser.switch_to.alert.dismiss
    end

    it 'CT11 - Prompt' do 
        accept_prompt(with: 'Leonardo') do
            click_button 'Prompt'
        end
    end
end