
describe 'Lista', :selecionaLista do

 it 'CT05 - Seleciona item em lista' do
    visit 'https://training-wheels-protocol.herokuapp.com/dropdown'
    # selecina opçao from elemento
    select('Steve Rogers', from: 'dropdown')
    sleep 3
    end

    it 'CT05 - Seleciona item em lista (2)' do
    visit 'https://training-wheels-protocol.herokuapp.com/dropdown'
    drop = find('.avenger-list')
    drop.find('option', text: 'Bucky').select_option
    sleep 2
    end
 end


