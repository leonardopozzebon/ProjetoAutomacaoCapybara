
describe 'Opção Unica - Radio', :selecionaOpcaoUnica  do
    it 'CT07 - Selecionar opcao unica' do
        visit 'https://training-wheels-protocol.herokuapp.com/radios'
        choose('thor')
        sleep 2
    end

    it 'CT07 - Selecionar opcao unica (2)' do
        visit 'https://training-wheels-protocol.herokuapp.com/radios'
        find('input[value=guardians]').click
        sleep 2
    end
end