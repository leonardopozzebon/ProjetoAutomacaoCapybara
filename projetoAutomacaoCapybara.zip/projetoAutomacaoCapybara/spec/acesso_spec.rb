#Autor: Leonardo Pozzebon
#describe -> criando a suite de teste
#it -> criando o caso de teste

describe "Acessando a pagina", :acesso do
    it "CT01 - Acessando a pagina" do
        visit "https://training-wheels-protocol.herokuapp.com/"
        #imprimindo o titulo da pagina no console
        puts "O titulo da pagina é: "
        puts page.title
        #validando o titulo da pagina atraves do rspec
        expect(page.title).to eql "Training Wheels Protocol"
    end
end