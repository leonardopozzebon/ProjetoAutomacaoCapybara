describe 'Login Formulario', :login_form do

    before(:each) do
        visit 'https://training-wheels-protocol.herokuapp.com/access'
    end

    it 'CT12 - Login Formulario' do
    #Trabalhando com 'escopo' -> Quando se tem mais de um elemento na pagina com o mesmo seletor
    login_form = find('#login')
    login_form.find('input[name=username]').set 'stark'
    login_form.find('input[name=password]').set 'jarvis!'

    click_button 'Entrar'
    expect(find('#flash')).to have_content 'Olá, Tony Stark. Você acessou a área logada!'
        end

    it 'CT12 - Login Formulario (2)' do

    within('#login') do
        find('input[name=username]').set 'stark'
        find('input[name=password]').set 'jarvis!'
        click_button 'Entrar'
        end
    end
end
